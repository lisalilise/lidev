function setupSlider(slider) {
  //query selector pour trouver les classes et les stocker des les var
    const sliderContainer = slider.querySelector('.slider-container');
    const prevButton = slider.querySelector('.prev-button');
    const nextButton = slider.querySelector('.next-button');
    const sliderImages = sliderContainer.querySelectorAll('.slider-image');
   //current index est l'index de l'image actuellement affiché
    let currentIndex = 0;
    //sliderCount est initialisé avec  nombre total d'images dans le diaporama
    const slideCount = sliderImages.length;
    const slideWidth = 50; 
  //mettre a jour la position des diapositives
    function updateSlidePosition() {
      sliderContainer.style.transform = `translateX(-${currentIndex * slideWidth}%)`;
    }
  //nextSlide est appelé quand on click sur le bouton
    function nextSlide() {
      currentIndex++;
      //si currentIndex>= a 3 qui est le nombre total d'images
      if (currentIndex >= slideCount) {
        currentIndex = 0;
      }
      updateSlidePosition();
    }
  
    function prevSlide() {
      currentIndex--;
      if (currentIndex < 0) {
        currentIndex = slideCount - 1;
      }
      updateSlidePosition();
    }
  
    prevButton.addEventListener('click', prevSlide);
    nextButton.addEventListener('click', nextSlide);
  }
  //pour trouver tous les elements de la classe slider
  const sliders = document.querySelectorAll('.slider');
  
  sliders.forEach(slider => {
    setupSlider(slider);
  });
  